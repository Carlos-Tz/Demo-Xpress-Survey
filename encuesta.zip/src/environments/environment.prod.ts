export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBUVev709JCTWW9zMSnqOkv0mZ4eTrgT-g",
    authDomain: "xpress-b9608.firebaseapp.com",
    databaseURL: "https://xpress-b9608.firebaseio.com",
    projectId: "xpress-b9608",
    storageBucket: "",
    messagingSenderId: "905015794232"
  }
};
